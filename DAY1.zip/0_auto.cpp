int main()
{
	int n1 = 0;

	auto a1 = 3;
	auto a2 = 3.4;
}

