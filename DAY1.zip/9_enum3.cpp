
enum class DAYOFWEEK { SUN = 0, MON = 1, TUE = 2 };

int main()
{
}




