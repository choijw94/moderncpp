template<typename T>
T square(T a)
{
	return a * a;
}