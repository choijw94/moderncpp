template<typename T>
T square(T a)
{
	return a * a;
}

//template double square(double);

int main()
{
//	square(3);
}