#include <iostream>

template<typename T> void foo(T a)
{
	std::cout << __FUNCSIG__ << std::endl;
//	std::cout << __PRETTY_FUNCTION__ << std::endl;
}

template<typename T> void goo(T& a)
{
	std::cout << __FUNCSIG__ << std::endl;
//	std::cout << __PRETTY_FUNCTION__ << std::endl;
}


int main()
{
	int x[3] = { 1,2,3 };

	foo(x); // T=?
	goo(x); 
}