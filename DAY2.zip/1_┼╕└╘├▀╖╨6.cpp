#include <iostream>

template<typename T> void foo(T a, T b)
{
}

template<typename T> void goo(T& a, T& b)
{
}


int main()
{
	foo("banana", "apple");

//	goo("banana", "apple");
}