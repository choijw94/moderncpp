#include <iostream>

int main()
{
	int x[3] = { 1,2,3 };

	auto a = x;

	decltype(x) d;
}