void f1(int&  r) {}
void f2(int&& r) {}

int main()
{
	int n = 3;

	f1(3);
	f1(n);

	f2(3);
	f3(n);
}

